/**
 * Created by Vako on 10/26/2016.
 */
public class RomanNumeral {
    private static int num;
    private static String romanNumeral = "";

    private static void extractRomanNumeralNumbersElevenToNineHundredNinetyNineThousandNineHundredNinetyNine (int minNum, int maxNum, int borderNum, String romanNum, String borderRomanNum) {
        while (num <= maxNum && num >= minNum) {
            if (num >= borderNum) {
                romanNumeral += borderRomanNum;
                num -= borderNum;
            } else {
                romanNumeral += romanNum;
                num -= minNum;
            }
        }
    }

    public static String convertIntegerToRomanNumeral (int inputNum) {

        /* Roman Numeral Chart
            1 - I    | 50 - L
            2 - II   | 100 - C
            3 - III  | 500 - D
            4 - IV   | 1000 - M
            5 - V    | 5000 - V\u0305
            6 - VI   | 10000 - X\u0305
            7 - VII  | 50000 - L\u0305
            8 - VIII | 100000 - C\u0305
            9 - IX   | 500000 - D\u0305
            10 - X   | 1000000 - M\u0305
         */

        num = inputNum;
        String baseTenRomanNum[] = {"I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};

        if (num <= 0) {
            return "The number " + num + " cannot be converted into a roman numeral";
        }

        while (num >= 1000000) { // adds one or more of "M\u0305"
            romanNumeral += "M\u0305";
            num -= 1000000;
        }

        extractRomanNumeralNumbersElevenToNineHundredNinetyNineThousandNineHundredNinetyNine (500000, 999999, 900000, "D\u0305", "C\u0305M\u0305"); // adds ("C\u0305M\u0305") or (one or more of "D\u0305") to class field romanNumeral
        extractRomanNumeralNumbersElevenToNineHundredNinetyNineThousandNineHundredNinetyNine (100000, 499999, 400000, "C\u0305", "C\u0305D\u0305"); // adds ("C\u0305D\u0305") or (one or more of "C\u0305") to class field romanNumeral
        extractRomanNumeralNumbersElevenToNineHundredNinetyNineThousandNineHundredNinetyNine (50000, 99999, 90000, "L\u0305", "X\u0305C\u0305"); // adds ("X\u0305C\u0305") or (one or more of "L\u0305") to class field romanNumeral
        extractRomanNumeralNumbersElevenToNineHundredNinetyNineThousandNineHundredNinetyNine (10000, 49999, 40000, "X\u0305", "X\u0305L\u0305"); // adds ("X\u0305L\u0305") or (one or more of "X\u0305") to class field romanNumeral
        extractRomanNumeralNumbersElevenToNineHundredNinetyNineThousandNineHundredNinetyNine (5000, 9999, 9000, "V\u0305", "MX\u0305"); // adds ("MX\u0305") or (one or more of "V\u0305") to class field romanNumeral
        extractRomanNumeralNumbersElevenToNineHundredNinetyNineThousandNineHundredNinetyNine (1000, 4999, 4000, "M", "MV\u0305"); // adds ("MV\u0305") or (one or more of "M") to class field romanNumeral
        extractRomanNumeralNumbersElevenToNineHundredNinetyNineThousandNineHundredNinetyNine (500, 999, 900, "D", "CM"); // adds ("CM") or (one or more of "D") to class field romanNumeral
        extractRomanNumeralNumbersElevenToNineHundredNinetyNineThousandNineHundredNinetyNine (100, 499, 400, "C", "CD"); // adds ("CD") or (one or more of "C") to class field romanNumeral
        extractRomanNumeralNumbersElevenToNineHundredNinetyNineThousandNineHundredNinetyNine (50, 99, 90, "L", "XC"); // adds ("XC") or (one or more of "L") to class field romanNumeral
        extractRomanNumeralNumbersElevenToNineHundredNinetyNineThousandNineHundredNinetyNine (10, 49, 40, "X", "XL"); // adds ("XL") or (one or more of "X") to class field romanNumeral

        switch (num) {
            case 1:
                romanNumeral += baseTenRomanNum[0]; break;
            case 2:
                romanNumeral += baseTenRomanNum[1]; break;
            case 3:
                romanNumeral += baseTenRomanNum[2]; break;
            case 4:
                romanNumeral += baseTenRomanNum[3]; break;
            case 5:
                romanNumeral += baseTenRomanNum[4]; break;
            case 6:
                romanNumeral += baseTenRomanNum[5]; break;
            case 7:
                romanNumeral += baseTenRomanNum[6]; break;
            case 8:
                romanNumeral += baseTenRomanNum[7]; break;
            case 9:
                romanNumeral += baseTenRomanNum[8]; break;
            case 10:
                romanNumeral += baseTenRomanNum[9]; break;
            default: romanNumeral += "";
        }
        String romanNumeralFound = romanNumeral;
        romanNumeral = ""; // reset roman numeral static class field
        return romanNumeralFound;
    }
}