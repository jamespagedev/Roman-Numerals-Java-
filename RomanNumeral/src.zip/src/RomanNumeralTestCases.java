/**
 * Created by Vako on 10/26/2016.
 */
public class RomanNumeralTestCases {
    private final String setStringColorReset = "\u001B[0m";
    private final String setStringColorGreenBold = "\u001B[1;32m";
    private final String setStringColorRedBold = "\u001B[1;31m";
    private int totalTestCases;
    private int testCasesPassed;
    private int testCasesFailed;

    RomanNumeralTestCases () {} // constructor

    public String ioTest (String testCaseName, String input, String expectedOutput) {
        if (input.equals(expectedOutput)){
            this.testCasesPassed++;
            this.totalTestCases++;
            return "Test Case - " + testCaseName + ": " + this.setStringColorGreenBold + "Pass" + this.setStringColorReset;
        } else {
            this.testCasesFailed++;
            this.totalTestCases++;
            return "Test Case - " + testCaseName + ": " + this.setStringColorRedBold + "Fail" +  "\n\tExpected output:\n" + expectedOutput + this.setStringColorReset;
        }
    }

    public String ioTest (String testCaseName, boolean input, boolean expectedOutput) {
        if (input == expectedOutput){
            this.testCasesPassed++;
            this.totalTestCases++;
            return "Test Case - " + testCaseName + ": " + this.setStringColorGreenBold + "Pass" + this.setStringColorReset;
        } else {
            this.testCasesFailed++;
            this.totalTestCases++;
            return "Test Case - " + testCaseName + ": " + this.setStringColorRedBold + "Fail" +  "\n\tExpected output:\n" + expectedOutput + this.setStringColorReset;
        }
    }

    public String displayTestResults () {
        return "Total Testcases Run " + this.totalTestCases + ":: " + this.testCasesPassed + this.setStringColorGreenBold + "Pass" + setStringColorReset + ": " + this.testCasesFailed + setStringColorRedBold + "Fall" + this.setStringColorReset;
    }

    public static void main(String[] args) {
        RomanNumeralTestCases tester = new RomanNumeralTestCases();

        System.out.println(tester.ioTest("zero", RomanNumeral.convertIntegerToRomanNumeral(0), "The number 0 cannot be converted into a roman numeral"));
        System.out.println(tester.ioTest("one", RomanNumeral.convertIntegerToRomanNumeral(1), "I"));
        System.out.println(tester.ioTest("two", RomanNumeral.convertIntegerToRomanNumeral(2), "II"));
        System.out.println(tester.ioTest("three", RomanNumeral.convertIntegerToRomanNumeral(3), "III"));
        System.out.println(tester.ioTest("four", RomanNumeral.convertIntegerToRomanNumeral(4), "IV"));
        System.out.println(tester.ioTest("five", RomanNumeral.convertIntegerToRomanNumeral(5), "V"));
        System.out.println(tester.ioTest("six", RomanNumeral.convertIntegerToRomanNumeral(6), "VI"));
        System.out.println(tester.ioTest("seven", RomanNumeral.convertIntegerToRomanNumeral(7), "VII"));
        System.out.println(tester.ioTest("eight", RomanNumeral.convertIntegerToRomanNumeral(8), "VIII"));
        System.out.println(tester.ioTest("nine", RomanNumeral.convertIntegerToRomanNumeral(9), "IX"));
        System.out.println(tester.ioTest("ten", RomanNumeral.convertIntegerToRomanNumeral(10), "X"));
        System.out.println(tester.ioTest("eleven", RomanNumeral.convertIntegerToRomanNumeral(11), "XI"));
        System.out.println(tester.ioTest("nineteen", RomanNumeral.convertIntegerToRomanNumeral(19), "XIX"));
        System.out.println(tester.ioTest("twenty", RomanNumeral.convertIntegerToRomanNumeral(20), "XX"));
        System.out.println(tester.ioTest("twentyOne", RomanNumeral.convertIntegerToRomanNumeral(21), "XXI"));
        System.out.println(tester.ioTest("twentyNine", RomanNumeral.convertIntegerToRomanNumeral(29), "XXIX"));
        System.out.println(tester.ioTest("thirty", RomanNumeral.convertIntegerToRomanNumeral(30), "XXX"));
        System.out.println(tester.ioTest("thirtyOne", RomanNumeral.convertIntegerToRomanNumeral(31), "XXXI"));
        System.out.println(tester.ioTest("thirtyNine", RomanNumeral.convertIntegerToRomanNumeral(39), "XXXIX"));
        System.out.println(tester.ioTest("forty", RomanNumeral.convertIntegerToRomanNumeral(40), "XL"));
        System.out.println(tester.ioTest("fortyOne", RomanNumeral.convertIntegerToRomanNumeral(41), "XLI"));
        System.out.println(tester.ioTest("fortyNine", RomanNumeral.convertIntegerToRomanNumeral(49), "XLIX"));
        System.out.println(tester.ioTest("fifty", RomanNumeral.convertIntegerToRomanNumeral(50), "L"));
        System.out.println(tester.ioTest("fiftyOne", RomanNumeral.convertIntegerToRomanNumeral(51), "LI"));
        System.out.println(tester.ioTest("fiftyNine", RomanNumeral.convertIntegerToRomanNumeral(59), "LIX"));
        System.out.println(tester.ioTest("sixty", RomanNumeral.convertIntegerToRomanNumeral(60), "LX"));
        System.out.println(tester.ioTest("sixtyOne", RomanNumeral.convertIntegerToRomanNumeral(61), "LXI"));
        System.out.println(tester.ioTest("eightyNine", RomanNumeral.convertIntegerToRomanNumeral(89), "LXXXIX"));
        System.out.println(tester.ioTest("ninety", RomanNumeral.convertIntegerToRomanNumeral(90), "XC"));
        System.out.println(tester.ioTest("ninetyOne", RomanNumeral.convertIntegerToRomanNumeral(91), "XCI"));
        System.out.println(tester.ioTest("ninetyNine", RomanNumeral.convertIntegerToRomanNumeral(99), "XCIX"));
        System.out.println(tester.ioTest("oneHundred", RomanNumeral.convertIntegerToRomanNumeral(100), "C"));
        System.out.println(tester.ioTest("oneHundredOne", RomanNumeral.convertIntegerToRomanNumeral(101), "CI"));
        System.out.println(tester.ioTest("oneHundredFortyNine", RomanNumeral.convertIntegerToRomanNumeral(149), "CXLIX"));
        System.out.println(tester.ioTest("oneHundredFifty", RomanNumeral.convertIntegerToRomanNumeral(150), "CL"));
        System.out.println(tester.ioTest("oneHundredFiftyOne", RomanNumeral.convertIntegerToRomanNumeral(151), "CLI"));
        System.out.println(tester.ioTest("oneHundredEightyNine", RomanNumeral.convertIntegerToRomanNumeral(189), "CLXXXIX"));
        System.out.println(tester.ioTest("oneHundredNinety", RomanNumeral.convertIntegerToRomanNumeral(190), "CXC"));
        System.out.println(tester.ioTest("oneHundredNinetyOne", RomanNumeral.convertIntegerToRomanNumeral(191), "CXCI"));
        System.out.println(tester.ioTest("threeHundred", RomanNumeral.convertIntegerToRomanNumeral(300), "CCC"));
        System.out.println(tester.ioTest("threeHundredNinety", RomanNumeral.convertIntegerToRomanNumeral(390), "CCCXC"));
        System.out.println(tester.ioTest("threeHundredNinetyOne", RomanNumeral.convertIntegerToRomanNumeral(391), "CCCXCI"));
        System.out.println(tester.ioTest("threeHundredNinetyNine", RomanNumeral.convertIntegerToRomanNumeral(399), "CCCXCIX"));
        System.out.println(tester.ioTest("fourHundred", RomanNumeral.convertIntegerToRomanNumeral(400), "CD"));
        System.out.println(tester.ioTest("fourHundredOne", RomanNumeral.convertIntegerToRomanNumeral(401), "CDI"));
        System.out.println(tester.ioTest("fourHundredFortyNine", RomanNumeral.convertIntegerToRomanNumeral(449), "CDXLIX"));
        System.out.println(tester.ioTest("fourHundredFifty", RomanNumeral.convertIntegerToRomanNumeral(450), "CDL"));
        System.out.println(tester.ioTest("fourHundredFiftyOne", RomanNumeral.convertIntegerToRomanNumeral(451), "CDLI"));
        System.out.println(tester.ioTest("fourHundredNinetyNine", RomanNumeral.convertIntegerToRomanNumeral(499), "CDXCIX"));
        System.out.println(tester.ioTest("fiveHundred", RomanNumeral.convertIntegerToRomanNumeral(500), "D"));
        System.out.println(tester.ioTest("fiveHundredOne", RomanNumeral.convertIntegerToRomanNumeral(501), "DI"));
        System.out.println(tester.ioTest("sevenHundredFortyNine", RomanNumeral.convertIntegerToRomanNumeral(749), "DCCXLIX"));
        System.out.println(tester.ioTest("sevenHundredFifty", RomanNumeral.convertIntegerToRomanNumeral(750), "DCCL"));
        System.out.println(tester.ioTest("sevenHundredFiftyOne", RomanNumeral.convertIntegerToRomanNumeral(751), "DCCLI"));
        System.out.println(tester.ioTest("eightHundredNinetyNine", RomanNumeral.convertIntegerToRomanNumeral(899), "DCCCXCIX"));
        System.out.println(tester.ioTest("nineHundred", RomanNumeral.convertIntegerToRomanNumeral(900), "CM"));
        System.out.println(tester.ioTest("nineHundredOne", RomanNumeral.convertIntegerToRomanNumeral(901), "CMI"));
        System.out.println(tester.ioTest("nineHundredNinetyNine", RomanNumeral.convertIntegerToRomanNumeral(999), "CMXCIX"));
        System.out.println(tester.ioTest("oneThousand", RomanNumeral.convertIntegerToRomanNumeral(1000), "M"));
        System.out.println(tester.ioTest("oneThousandOne", RomanNumeral.convertIntegerToRomanNumeral(1001), "MI"));
        System.out.println(tester.ioTest("twoThousandNineHundredNinetyNine", RomanNumeral.convertIntegerToRomanNumeral(2999), "MMCMXCIX"));
        System.out.println(tester.ioTest("threeThousand", RomanNumeral.convertIntegerToRomanNumeral(3000), "MMM"));
        System.out.println(tester.ioTest("threeThousandOne", RomanNumeral.convertIntegerToRomanNumeral(3001), "MMMI"));
        System.out.println(tester.ioTest("threeThousandNinetyNine", RomanNumeral.convertIntegerToRomanNumeral(3099), "MMMXCIX"));
        System.out.println(tester.ioTest("fourThousand", RomanNumeral.convertIntegerToRomanNumeral(4000), "MV\u0305"));
        System.out.println(tester.ioTest("fourThousandOne", RomanNumeral.convertIntegerToRomanNumeral(4001), "MV\u0305I"));
        System.out.println(tester.ioTest("fourThousandNineHundredNinetyNine", RomanNumeral.convertIntegerToRomanNumeral(4999), "MV\u0305CMXCIX"));
        System.out.println(tester.ioTest("fiveThousand", RomanNumeral.convertIntegerToRomanNumeral(5000), "V\u0305"));
        System.out.println(tester.ioTest("fiveThousandOne", RomanNumeral.convertIntegerToRomanNumeral(5001), "V\u0305I"));
        System.out.println(tester.ioTest("sevenThousandFourHundredNinetyNine", RomanNumeral.convertIntegerToRomanNumeral(7499), "V\u0305MMCDXCIX"));
        System.out.println(tester.ioTest("sevenThousandFiveHundred", RomanNumeral.convertIntegerToRomanNumeral(7500), "V\u0305MMD"));
        System.out.println(tester.ioTest("sevenThousandFiveHundredOne", RomanNumeral.convertIntegerToRomanNumeral(7501), "V\u0305MMDI"));
        System.out.println(tester.ioTest("eightThousandNineHundredNinetyNine", RomanNumeral.convertIntegerToRomanNumeral(8999), "V\u0305MMMCMXCIX"));
        System.out.println(tester.ioTest("nineThousand", RomanNumeral.convertIntegerToRomanNumeral(9000), "MX\u0305"));
        System.out.println(tester.ioTest("nineThousandOne", RomanNumeral.convertIntegerToRomanNumeral(9001), "MX\u0305I"));
        System.out.println(tester.ioTest("nineThousandNineHundredNinetyNine", RomanNumeral.convertIntegerToRomanNumeral(9999), "MX\u0305CMXCIX"));
        System.out.println(tester.ioTest("tenThousand", RomanNumeral.convertIntegerToRomanNumeral(10000), "X\u0305"));
        System.out.println(tester.ioTest("tenThousandOne", RomanNumeral.convertIntegerToRomanNumeral(10001), "X\u0305I"));
        System.out.println(tester.ioTest("twentyFourThousandNineHundredNinetyNine", RomanNumeral.convertIntegerToRomanNumeral(24999), "X\u0305X\u0305MV\u0305CMXCIX"));
        System.out.println(tester.ioTest("twentyFiveThousand", RomanNumeral.convertIntegerToRomanNumeral(25000), "X\u0305X\u0305V\u0305"));
        System.out.println(tester.ioTest("twentyFiveThousandOne", RomanNumeral.convertIntegerToRomanNumeral(25001), "X\u0305X\u0305V\u0305I"));
        System.out.println(tester.ioTest("fortyNineThousandNineHundredNinetyNine", RomanNumeral.convertIntegerToRomanNumeral(49999), "X\u0305L\u0305MX\u0305CMXCIX"));
        System.out.println(tester.ioTest("fiftyThousand", RomanNumeral.convertIntegerToRomanNumeral(50000), "L\u0305"));
        System.out.println(tester.ioTest("fiftyThousandOne", RomanNumeral.convertIntegerToRomanNumeral(50001), "L\u0305I"));
        System.out.println(tester.ioTest("seventyFourThousandNineHundredNinetyNine", RomanNumeral.convertIntegerToRomanNumeral(74999), "L\u0305X\u0305X\u0305MV\u0305CMXCIX"));
        System.out.println(tester.ioTest("seventyFiveThousand", RomanNumeral.convertIntegerToRomanNumeral(75000), "L\u0305X\u0305X\u0305V\u0305"));
        System.out.println(tester.ioTest("seventyFiveThousandOne", RomanNumeral.convertIntegerToRomanNumeral(75001), "L\u0305X\u0305X\u0305V\u0305I"));
        System.out.println(tester.ioTest("eightyNineThousandNineHundredNinetyNine", RomanNumeral.convertIntegerToRomanNumeral(89999), "L\u0305X\u0305X\u0305X\u0305MX\u0305CMXCIX"));
        System.out.println(tester.ioTest("ninetyThousand", RomanNumeral.convertIntegerToRomanNumeral(90000), "X\u0305C\u0305"));
        System.out.println(tester.ioTest("ninetyThousandOne", RomanNumeral.convertIntegerToRomanNumeral(90001), "X\u0305C\u0305I"));
        System.out.println(tester.ioTest("ninetyNineThousandNineHundredNinetyNine", RomanNumeral.convertIntegerToRomanNumeral(99999), "X\u0305C\u0305MX\u0305CMXCIX"));
        System.out.println(tester.ioTest("oneHundredThousand", RomanNumeral.convertIntegerToRomanNumeral(100000), "C\u0305"));
        System.out.println(tester.ioTest("oneHundredThousandOne", RomanNumeral.convertIntegerToRomanNumeral(100001), "C\u0305I"));
        System.out.println(tester.ioTest("twoHundredFortyNineThousandNineHundredNinetyNine", RomanNumeral.convertIntegerToRomanNumeral(249999), "C\u0305C\u0305X\u0305L\u0305MX\u0305CMXCIX"));
        System.out.println(tester.ioTest("twoHundredFiftyThousand", RomanNumeral.convertIntegerToRomanNumeral(250000), "C\u0305C\u0305L\u0305"));
        System.out.println(tester.ioTest("twoHundredFiftyThousandOne", RomanNumeral.convertIntegerToRomanNumeral(250001), "C\u0305C\u0305L\u0305I"));
        System.out.println(tester.ioTest("fourHundredNinetyNineThousandNineHundredNinetyNine", RomanNumeral.convertIntegerToRomanNumeral(499999), "C\u0305D\u0305X\u0305C\u0305MX\u0305CMXCIX"));
        System.out.println(tester.ioTest("fiveHundredThousand", RomanNumeral.convertIntegerToRomanNumeral(500000), "D\u0305"));
        System.out.println(tester.ioTest("fiveHundredThousandOne", RomanNumeral.convertIntegerToRomanNumeral(500001), "D\u0305I"));
        System.out.println(tester.ioTest("sevenHundredFortyNineThousandNineHundredNinetyNine", RomanNumeral.convertIntegerToRomanNumeral(749999), "D\u0305C\u0305C\u0305X\u0305L\u0305MX\u0305CMXCIX"));
        System.out.println(tester.ioTest("sevenHundredFiftyThousand", RomanNumeral.convertIntegerToRomanNumeral(750000), "D\u0305C\u0305C\u0305L\u0305"));
        System.out.println(tester.ioTest("sevenHundredFiftyThousandOne", RomanNumeral.convertIntegerToRomanNumeral(750001), "D\u0305C\u0305C\u0305L\u0305I"));
        System.out.println(tester.ioTest("eightHundredNinetyNineThousandNineHundredNinetyNine", RomanNumeral.convertIntegerToRomanNumeral(899999), "D\u0305C\u0305C\u0305C\u0305X\u0305C\u0305MX\u0305CMXCIX"));
        System.out.println(tester.ioTest("nineHundredThousand", RomanNumeral.convertIntegerToRomanNumeral(900000), "C\u0305M\u0305"));
        System.out.println(tester.ioTest("nineHundredThousandOne", RomanNumeral.convertIntegerToRomanNumeral(900001), "C\u0305M\u0305I"));
        System.out.println(tester.ioTest("nineHundredNinetyNineThousandNineHundredNinetyNine", RomanNumeral.convertIntegerToRomanNumeral(999999), "C\u0305M\u0305X\u0305C\u0305MX\u0305CMXCIX"));
        System.out.println(tester.ioTest("oneMillion", RomanNumeral.convertIntegerToRomanNumeral(1000000), "M\u0305"));
        System.out.println(tester.ioTest("oneMillionOne", RomanNumeral.convertIntegerToRomanNumeral(1000001), "M\u0305I"));
        System.out.println(tester.ioTest("oneMillionEleven", RomanNumeral.convertIntegerToRomanNumeral(1000011), "M\u0305XI"));
        System.out.println(tester.ioTest("oneMillionOneHundredEleven", RomanNumeral.convertIntegerToRomanNumeral(1000111), "M\u0305CXI"));
        System.out.println(tester.ioTest("oneMillionOneThousandOneHundredEleven", RomanNumeral.convertIntegerToRomanNumeral(1001111), "M\u0305MCXI"));
        System.out.println(tester.ioTest("oneMillionElevenThousandOneHundredEleven", RomanNumeral.convertIntegerToRomanNumeral(1011111), "M\u0305X\u0305MCXI"));
        System.out.println(tester.ioTest("oneMillionOneHundredElevenThousandOneHundredEleven", RomanNumeral.convertIntegerToRomanNumeral(1111111), "M\u0305C\u0305X\u0305MCXI"));
        System.out.println();

        System.out.println(tester.displayTestResults());
    }
}